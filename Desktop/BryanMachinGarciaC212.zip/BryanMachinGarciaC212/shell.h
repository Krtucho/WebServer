typedef struct {
    char*** ListHistory;
} History;

typedef struct
{
    int pid;
    char * name;
}PidBg;
typedef struct
{
    PidBg ** list;
    int length;
    int count;
}ListPid;

typedef struct {
  char** Args;
  char ** Redir;
}Command;
Command **Parser(int *PC, int *Bg,int *Save);


void Length(int *length, char* name);


void SaveHistory();

Command** BuildExpression(char** Line, int Procesos,int *PC, int *Bg);


void PrintHistory();

int CD(char** cd);

ListPid * CreateLPid(int length);

void AddPid_ListPid(int pid, char * namepid);

int DeletePid(int pid);

void childProcDead();

void PrintLPid();

void ControlC();

int Execute(Command** Commands, int PC, int Bg, int Save);
