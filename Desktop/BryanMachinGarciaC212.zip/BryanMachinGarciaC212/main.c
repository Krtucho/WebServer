#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <wait.h>
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>
#include "shell.h"

ListPid* LPid;
char** Line;
int cant;
int Control;
int PidEject;

int main()
{


    signal(SIGCHLD, childProcDead);

    signal(SIGINT,ControlC);


    LPid = CreateLPid(100);

     while(1)
     {

        Control=0;
        printf("\nBryanShell$ ");

        int PC;
        int Bg;
        int Save;
        Command** Commands = Parser(&PC, &Bg, &Save);


        Execute(Commands, PC, Bg, Save);


         for (int i = 1; i < PC; ++i) {
             free(Commands[i]);
         }
         free(Commands);

         for (int j = 0; j < cant; ++j) {
             free(Line[j]);
         }
         free(Line);
     }
    return 0;
}

Command **Parser(int *PC , int *Bg, int *Save)
{
    Line = calloc(100,sizeof(char*));
    int Procesos = 1;
    cant = 0;
    char b = 'a';
    *Save = 1;

    scanf("%c",&b);

    while(b != 10)
    {
        if (b == ' ' && cant == 0) *Save = 0;

        int n = 0;

        if (b != ' ') {
            char* temp = calloc(100,sizeof(char));

            while (b != ' ') {

                if (b == 35) {
                    if(cant == 0) *Save = 0;
                    while(b != 10)
                    {
                        scanf("%c", &b);
                    }
                    n = 0;
                   break;
                }

                temp[n] = b;
                n++;
                scanf("%c", &b);
                if (b == 10) break;
            }

            if(n)
            {
                char* string = (char*)calloc(n,sizeof(char));

                Line[cant] = (char*)calloc(n,sizeof(char));


                for (int i = 0; i < n; i++)
                {

                    string[i] = temp[i];
                }
                if (strcmp(string, "|") == 0)
                    Procesos++;

                    strcpy(Line[cant],string);

                    cant++;
                free(temp);
            }

        }
        if (b == 10) break;
        scanf("%c", &b);

    }




    Command** Commands = BuildExpression(Line,Procesos,PC,Bg);
    return Commands;
}

Command** BuildExpression(char** Line, int Procesos, int *PC, int *Bg)
{
    *Bg = (strcmp(Line[(cant) - 1], "&") == 0) ? 1 : 0;
    *PC = Procesos;

    Command** Comandos = (Command**)calloc(Procesos+1,sizeof(Command*));

    int Pos = 0;
    int a = 0;
    int r = 0;
    Comandos[Pos] = (Command*)malloc(sizeof(Command));
    Comandos[Pos]->Args = (char**)calloc(10,sizeof(char*));
    Comandos[Pos]->Redir = (char**)calloc(10,sizeof(char*));

    for (int j = 0; j < cant; ++j) {
        if(strcmp(Line[j],"|") == 0)
        {
            if(a == 0) return NULL;
            Comandos[Pos]->Redir[r] = NULL;
            Comandos[Pos]->Args[a] = NULL;
            a=r=0;
            Pos++;
            Comandos[Pos] = (Command*)malloc(sizeof(Command));
            Comandos[Pos]->Args = (char**)calloc(10,sizeof(char*));
            Comandos[Pos]->Redir = (char**)calloc(10,sizeof(char*));
        }
        else if(!strcmp(Line[j],"<") || !strcmp(Line[j],">") || !strcmp(Line[j],">>"))
        {
            char* c = (strcmp(Line[j],"<")==0)? "<":">";
            if(!strcmp(Line[j],">>"))
            {
                c = ">>";
            }
            Comandos[Pos]->Redir[r] = c;
            r++;
            j++;
            Comandos[Pos]->Redir[r] = Line[j];
            r++;
        }
        else
        {
            Comandos[Pos]->Args[a] = Line[j];
            a++;
        }
    }
    Comandos[Pos]->Args[a] = NULL;
    Comandos[Pos]->Redir[r] = NULL;
    Comandos[Pos+1] = NULL;

    return Comandos;
}

void Length(int *length, char* name)
{

    FILE* file = fopen(name,"r");
    while(!feof(file))
    {
        if(fgetc(file) == '\n')
            *length = *length + 1;
    }
    fclose(file);
}

void SaveHistory()
{
    FILE* fd = fopen("History","a");
    int x = 0;
    while (x != cant) {
        char *n = Line[x];
        if (x < cant - 1)
            fprintf(fd, "%s ", n);
        else {
            fprintf(fd, "%s\n", n);
        }
        x++;
    }
    fclose(fd);
    int Cant = 0;
    Length(&Cant,"History");

    if(Cant > 10)
    {

        FILE* NewFd = fopen("Temp","a");
        fd = fopen("History","r");
        char* a = calloc(100,sizeof(char*));

        while(fgetc(fd) != 10){}

        x = 0;
        while (x < 10) {
            char b = 'b';
            while (b != 10) {
                fscanf(fd, "%s", a);

                 fprintf(NewFd, "%s", a);

                fscanf(fd,"%c", &b);
                if (b == ' ') fprintf(NewFd, "%s", " ");
            }
            fprintf(NewFd, "\n");
        x++;
        }
        fclose(NewFd);
        fclose(fd);

        remove("History");
        rename("Temp","History");
    }

}

void PrintHistory()
{
    FILE* fd = fopen("History","r");
    int num = 1;
    int length = 0;
    Length(&length,"History");

    char* m;
    while (num <= length)
    {
        m = calloc(100,sizeof(char*));
        fscanf(fd,"%s",m);
        printf("%d: %s ",num,m);

        while (!feof(fd) && fgetc(fd) != 10)
        {
            fscanf(fd,"%s",m);
            printf("%s ",m);
        }
        printf("\n");
        num++;
    }
   fclose(fd);

}

int CD(char** cd)
{
    if(cd[1] == NULL) return 0;
    if(chdir(cd[1])==-1){
        perror("cd");
        return -1;
    }
    return 0;
}

int Execute(Command** Commands, int PC, int Bg, int Save)
{
    if(Bg)
    {
        for (int i = 0; i < 100; ++i) {
            if(strcmp(Commands[PC - 1]->Args[i],"&")==0)
            {
                Commands[PC - 1]->Args[i] = NULL;
                break;
            }
        }
    }

    int status;
    int r = 0;
    int pipes[PC-1][2];
    for (int i = 0; i < PC-1; ++i) {
       pipe(pipes[i]);
    }
    if(Save && (strcmp(Commands[0]->Args[0],"again")!=0)){SaveHistory();}
    for (int j = 0; j < PC; ++j) {

         Command* Comando = Commands[j];


        if(strcmp(Comando->Args[0],"again")==0){

            Line = calloc(100,sizeof(char*));

            int Procesos = 1;
            FILE* fd = fopen("History","r");
            int num = 1;
            int Num = atoi(Comando->Args[1]);
            int length = 0;
            Length(&length,"History");

            if(Num < 1 || Num > length) {
                printf("%s","No es posible.");
               return 1;
            }
            char* m = calloc(100,sizeof(char));
            while (num < Num)
            {
                fscanf(fd,"%s",m);
                if(fgetc(fd) == 10)
                    num++;
            }
            int aux = 0;
            char a = ' ';
            while (a != 10)
            {
                fscanf(fd,"%s",m);

                Line[aux] = calloc(100,sizeof(m));
                if(strcmp(m,"|")==0) Procesos++;
                strcpy(Line[aux++], m);
                fscanf(fd,"%c",&a);
            }
            cant = aux;
            fclose(fd);



            if(Line == NULL)
           {
               printf("%s","No es posible.");
               return 1;
           } else {
               int PCAUX;
               int BgAUX;


                SaveHistory();

               free(Commands);
               Command** CommandsAUX = BuildExpression(Line,Procesos,&PCAUX,&BgAUX);

               Execute(CommandsAUX,PCAUX,BgAUX,0);
                free(CommandsAUX);
            }
        }
        else if (strcmp(Comando->Args[0],"help")==0)
        {
            FILE* fd;

            if(Comando->Args[1] == NULL)
            {
                fd = fopen("Help","r");
            }
            else if (strcmp(Comando->Args[1],"history")==0)
            {
                fd = fopen("HelpHistory","r");
            }
            else if (strcmp(Comando->Args[1],"multi-pipe")==0)
            {
                fd = fopen("HelpMultiPipe","r");
            }
            else if (strcmp(Comando->Args[1],"basic")==0 || strcmp(Comando->Args[1],"spaces")==0)
            {
                fd = fopen("HelpBasic","r");
            }
            else if (strcmp(Comando->Args[1],"control+c")==0)
            {
                fd = fopen("HelpControl","r");
            }
            else if (strcmp(Comando->Args[1],"background")==0)
            {
                fd = fopen("HelpBackground","r");
            }
            int c;
            if(fd == NULL)
            {
                perror("Error");
                return -1;
            }
            do
                {
                c = fgetc(fd);
                if(feof(fd))
                    break;
                printf("%c",c);
                }
            while(1);

            fclose(fd);
            return 0;
        }
        else if(strcmp(Comando->Args[0],"cd")==0){
            if(CD(Comando->Args)==-1)return 1;
        }
        else if (strcmp(Comando->Args[0],"exit")==0){
            exit(0);
        }
        else if(strcmp(Comando->Args[0],"fg")==0)
        {
            if(Comando->Args[1] == NULL)
            {
                DeletePid(0);
            }
            else if(DeletePid(strtol(Comando->Args[1],NULL,10)) == -1)
            {
                printf("%s: no such job\n",Comando->Args[1]);
                exit(0);
            }
        }



        int Child_Pid = fork();
        PidEject = Child_Pid;
        if (Child_Pid == 0) {
            if(j == 0 && PC > 1)
                dup2(pipes[j][1], STDOUT_FILENO);
            else if (j == PC -1 && PC > 1)
                dup2(pipes[j-1][0], STDIN_FILENO);
            else if(PC > 1)
            {
                dup2(pipes[j][1], STDOUT_FILENO);
                dup2(pipes[j-1][0], STDIN_FILENO);
            }
            while(Comando->Redir[r] != NULL)
            {
                if(strcmp(Comando->Redir[r],"<") == 0)
                {
                    r++;
                    int Fd = open(Comando->Redir[r],O_RDONLY);
                    if(Fd == -1)
                    {
                        perror(NULL);
                        exit(0);
                    }
                    dup2(Fd,STDIN_FILENO);
                    r++;
                }
                else
                {
                    int Flags = (strcmp(Comando->Redir[r],">")==0)? O_WRONLY|O_CREAT|O_TRUNC:O_WRONLY|O_CREAT|O_APPEND;
                    r++;
                    int Fd = open(Comando->Redir[r],Flags,0664);
                    if(Fd == -1)
                    {
                        perror(NULL);
                        exit(0);
                    }
                    dup2(Fd,STDOUT_FILENO);
                    r++;
                }
            }

            if(execvp(Comando->Args[0],Comando->Args)== -1){
                if(errno == ENOENT){
                    if(strcmp(Comando->Args[0],"history")==0){
                        PrintHistory();
                    }
                    else if(strcmp(Comando->Args[0],"jobs") == 0)
                    {
                        PrintLPid();
                    }
                } else
                 perror(Comando->Args[0]);
                    exit(0);


            }
        } else {

            if(j == 0 && PC > 1)
                close(pipes[j][1]);
            else if (j == PC -1 && PC > 1)
                close(pipes[j-1][0]);
            else if(PC > 1)
            {
                close(pipes[j][1]);
                close(pipes[j-1][0]);
            }
            if(Bg)
            {
                AddPid_ListPid(Child_Pid,Comando->Args[0]);
            } else
            {
            waitpid(Child_Pid, &status, 0);
            }
        }

    }

    return 0;
}







ListPid * CreateLPid(int length)
{
    ListPid *list = (ListPid *)malloc(sizeof(ListPid));
    list->list = (PidBg **)malloc(sizeof(PidBg *) * length);
    list->count = 0;
    list->length = length;
    return list;
}

void AddPid_ListPid(int pid, char * namepid)
{
    PidBg * new_pidbg = (PidBg *)malloc(sizeof(PidBg));
    new_pidbg->pid = pid;

    int length = strlen(namepid);
    new_pidbg->name = malloc(length + 1);
    strcpy(new_pidbg->name,namepid);

    if(LPid->count == LPid->length)
    {
        ListPid * LPidAUX = CreateLPid(LPid->length * 2);
        int i;
        for(i = 0; i < LPid->count; i++)
            LPidAUX->list[i] = LPid->list[i];
        LPidAUX->count = LPid->count;

        free(LPid);

        LPid = LPidAUX;
    }
    LPid->list[LPid->count] = new_pidbg;
    LPid->count++;
}
int DeletePid(int pid)
{
    if(pid == 0)
    {
        int i = LPid->count-1;
        free(LPid->list[i]);
        LPid->count--;
        return 0;
    }
    for (int i = 0; i < LPid->count; i++)
    {
        if(LPid->list[i]->pid == pid)
        {
            free(LPid->list[i]);

            for (int j = i; j < LPid->count-1; ++j) {
                LPid->list[j] = LPid->list[j+1];
            }
            LPid->list[LPid->count - 1] = 0;
            LPid->count--;
            return 0;
        }
    }
    return -1;
}
void childProcDead()
{
    int status;
    int child_pid = waitpid(-1, &status, WNOHANG);
    DeletePid(child_pid);
    while(child_pid != 0 && child_pid != -1)
    {
        child_pid = waitpid(-1, &status, WNOHANG);
        DeletePid(child_pid);
    }
}
void PrintLPid()
{
    int i;
    for (i = 0; i < LPid->count; ++i)
    {
        printf("%d\t%s\n", LPid->list[i]->pid, LPid->list[i]->name);
    }
}


void ControlC()
{
    if(Control)
    {

        kill(PidEject,SIGKILL);
    } else
    {
        Control= 1;
    }

}